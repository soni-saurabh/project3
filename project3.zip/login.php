<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap.css">
</head>
<body>
	<!DOCTYPE html>
<html>
<head>
	<title>nutrilife</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="all" />
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<div class="bgimage">
		<div class="menu">
			<div class="leftmenu">
				<h1>
					<a href="file:///C:/xampp/htdocs/nutrilife/index.html">NutriLife</a>
				</h1>
			</div>
			<div class="rightmenu">
				<ol>
					<li><a href="file:///C:/xampp/htdocs/nutrilife/index.html">home</a></li>
					<li>Services</li>
					<li>about us</li>
					<li><a href="http://localhost/nutrilife/login.php">login</a></li>
					<li><a href="http://localhost/nutrilife/login.php">signup</a></li>
					
				</ol>
			</div>
		</div>
		<div class="text">
			<h1><i>Stay Healthy</i></h1>
			<div class="maindiv">

				
			
	</div>
	<div class="hoho">
		
	</div>

<

		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<h2>Login Form</h2>

					<form action="validation.php" method="post">
						<div class="form-group">
							<label> username </label>
							<input type="text" name="user" class="form-control">
							
						</div>
						<div class="form-group">
							<label> password </label>
							<input type="password" name="password" class="form-control">
							
						</div>

						<button  type="submit" class="btn btn-primary"> login </button>
						
					</form>
				    </div>
				    <br>
				    <br>
				    <br>
				    <br>

					<div class="col-lg-6">
					<h2>signup Form</h2>

					<form action="registration.php" method="post">
						<div class="form-group">
							<label> username </label>
							<input type="text" name="user" class="form-control">
							
						</div>
						<div class="form-group">
							<label> password </label>
							<input type="password" name="password" class="form-control">
							
						</div>

						<button type="submit" class="btn btn-primary"> signup </button>
						
					</form>
					
			</div>
				 
		</div>
</div>

</body>
</html>